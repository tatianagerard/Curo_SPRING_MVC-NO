package impacta.com.cadastroescola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroEscolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroEscolaApplication.class, args);
	}

}
