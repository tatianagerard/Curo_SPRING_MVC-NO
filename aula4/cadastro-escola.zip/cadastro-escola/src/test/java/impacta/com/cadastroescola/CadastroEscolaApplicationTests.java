package impacta.com.cadastroescola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroEscolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
